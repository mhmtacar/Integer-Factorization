# gtu-presentation
This is a LaTeX/beamer style file for the Final Project (Bitirme Projesi) presentation style in Gebze Technical University (GTU). 
